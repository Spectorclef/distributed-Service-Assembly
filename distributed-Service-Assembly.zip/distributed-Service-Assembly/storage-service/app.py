from flask import Flask, jsonify, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data', methods=['GET'])
def get_data():
    dummy_data = {
        "message": "Hello, this is dummy data!",
        "data": [1, 2, 3, 4, 5]
    }
    return jsonify(dummy_data)

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "Storage service is running"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)