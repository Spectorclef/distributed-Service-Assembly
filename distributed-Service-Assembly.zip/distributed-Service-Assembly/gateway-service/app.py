from flask import Flask, jsonify, request, render_template
import requests
import logging
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import threading
import time
import psutil
import signal
import sys
from routes.service1 import service1_bp

app = Flask(__name__)

# Register the blueprint
app.register_blueprint(service1_bp)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Connection pooling
session = requests.Session()
retry = Retry(connect=3, backoff_factor=0.5)
adapter = HTTPAdapter(max_retries=retry)
session.mount('http://', adapter)

# Health check function
def health_check():
    while True:
        try:
            response = session.get('http://storage-service:5000/health')
            if response.status_code == 200:
                logging.info("Storage service is healthy")
            else:
                logging.warning("Storage service health check failed")
        except requests.exceptions.RequestException as e:
            logging.error(f"Storage service health check error: {e}")
        time.sleep(60)  # Perform health check every 60 seconds

# Resource monitoring function
def resource_monitor():
    while True:
        cpu_usage = psutil.cpu_percent(interval=1)
        memory_usage = psutil.virtual_memory().percent
        logging.info(f"CPU usage: {cpu_usage}%, Memory usage: {memory_usage}%")
        time.sleep(60)  # Log resource usage every 60 seconds

# Background task function
def background_task():
    while True:
        logging.info("Performing background task...")
        # Add your background task logic here
        time.sleep(300)  # Perform background task every 5 minutes

# Keepalive mechanism
def keepalive():
    while True:
        try:
            session.get('http://storage-service:5000/keepalive')
            logging.info("Keepalive request sent to storage service")
        except requests.exceptions.RequestException as e:
            logging.error(f"Keepalive request error: {e}")
        time.sleep(300)  # Send keepalive request every 5 minutes

# Graceful shutdown handler
def graceful_shutdown(signum, frame):
    logging.info("Received shutdown signal, shutting down gracefully...")
    # Perform any cleanup tasks here
    sys.exit(0)

# Register signal handlers for graceful shutdown
signal.signal(signal.SIGTERM, graceful_shutdown)
signal.signal(signal.SIGINT, graceful_shutdown)

# Start health check thread
health_check_thread = threading.Thread(target=health_check)
health_check_thread.daemon = True
health_check_thread.start()

# Start resource monitoring thread
resource_monitor_thread = threading.Thread(target=resource_monitor)
resource_monitor_thread.daemon = True
resource_monitor_thread.start()

# Start background task thread
background_task_thread = threading.Thread(target=background_task)
background_task_thread.daemon = True
background_task_thread.start()

# Start keepalive thread
keepalive_thread = threading.Thread(target=keepalive)
keepalive_thread.daemon = True
keepalive_thread.start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/health', methods=['GET'])
def health_check_endpoint():
    return jsonify({"status": "Gateway service is running"}), 200

if __name__ == '__main__':
    logging.info("Starting gateway service...")
    app.run(host='0.0.0.0', port=8080)